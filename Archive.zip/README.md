# boekdb.v2.plugin


Deliverable: boekdb-plugin-v2.zip
