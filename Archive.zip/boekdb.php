<?php
/**
 * Plugin Name: BoekDB.v2
 * Plugin URI: https://www.boekdbv2.nl/
 * Description: Wordpress plugin for BoekDBv2 data.
 * Version: 1.1.0
 * Author: Icontact B.V.
 * Author URI: http://www.icontact.nl
 * Requires at least: 5.5
 * Requires PHP: 7.0
 *
 * @package BoekDB
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'BOEKDB_PLUGIN_FILE' ) ) {
	define( 'BOEKDB_PLUGIN_FILE', __FILE__ );
}
if ( ! defined( 'BOEKDB_ABSPATH' ) ) {
	define( 'BOEKDB_ABSPATH', dirname( BOEKDB_PLUGIN_FILE ) . '/' );
}
if ( ! defined( 'BOEKDB_PLUGIN_BASENAME' ) ) {
	define( 'BOEKDB_PLUGIN_BASENAME', plugin_basename( BOEKDB_PLUGIN_FILE ) );
}

// Include the main BoekDB class.
if ( ! class_exists( 'BoekDB', false ) ) {
	include_once dirname( BOEKDB_PLUGIN_FILE ) . '/includes/class-boekdb.php';
}

$boekdb_import_options = [
	'overwrite_images',
];

/**
 * Returns the main instance of BoekDB.
 *
 * @return BoekDB
 */
function BoekDB() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return BoekDB::instance();
}

function boekdb_debug( $message ) {
	if ( WP_DEBUG && WP_DEBUG_LOG ) {
		if ( ! is_string( $message ) ) {
			$message = var_export( $message, true );
		}
		/**
		 * @noinspection ForgottenDebugOutputInspection
		 */
		error_log( $message );
	}
}

BoekDB();

function boekdb_set_import_option( $name, $value ) {
	global $boekdb_import_options;
	boekdb_debug( 'set import option ' . $name . ': ' . $value );
	if ( in_array( $name, $boekdb_import_options ) ) {
		set_transient( 'boekdb_import_options_' . $name, $value, MINUTE_IN_SECONDS * 10 );
	}
}

function boekdb_unset_import_options() {
	global $boekdb_import_options;
	boekdb_debug( 'Unsetting import options' );
	foreach ( $boekdb_import_options as $option ) {
		delete_transient( 'boekdb_import_options_' . $option );
	}
}

function boekdb_is_import_running() {
	global $wpdb;

	$count = (int)$wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}boekdb_etalages WHERE running > 0" );
	if($count > 0) {
		boekdb_debug( 'Import is running' );
		return true;
	}
	boekdb_debug( 'Import is not running' );
	return false;
}

function boekdb_reset_import_running() {
	boekdb_debug( 'Resetting import running and etalage transients' );

	delete_transient( 'boekdb_import_etalage' );
	boekdb_unset_import_options();
}

function boekdb_boek_data( $id ) {
	$data = array();
	$meta = get_post_meta( $id );
	foreach ( $meta as $name => $value ) {
		if ( substr( $name, 0, 7 ) === 'boekdb_' ) {
			$data[ substr( $name, 7 ) ] = $value[0];
		}
		if ( $name === 'boekdb_recensiequotes' ) {
			$quotes = unserialize($value[0]);
			$parsed = array();
			foreach($quotes as $quote) {
				if($quote['tonen']) {
					unset($quote['tonen']);
					$parsed[] = $quote;
				}
			}
			$data[ substr( $name, 7 ) ] = serialize($parsed);
		}
	}

	$series = wp_get_object_terms( $id, 'boekdb_serie_tax' );
	if ( ! empty( $series ) ) {
		$data = array_merge( $data, boekdb_serie_data( $series[0]->term_id, $series[0] ) );
	}

	return $data;
}

function boekdb_betrokkenen_data( $id ) {
	$data = array();
	foreach ( wp_get_post_terms( $id, 'boekdb_auteur_tax' ) as $term ) {
		$data['auteurs'][] = array_merge( array( 'rol' => 'auteur' ), boekdb_betrokkene_data( $term->id, $term ) );
	}
	foreach ( wp_get_post_terms( $id, 'boekdb_spreker_tax' ) as $term ) {
		$data['sprekers'][] = array_merge( array( 'rol' => 'spreker' ), boekdb_betrokkene_data( $term->id, $term ) );
	}
	foreach ( wp_get_post_terms( $id, 'boekdb_illustrator_tax' ) as $term ) {
		$data['illustrators'][] = array_merge( array( 'rol' => 'illustrator' ),
			boekdb_betrokkene_data( $term->id, $term ) );
	}

	return $data;
}

function boekdb_betrokkene_data( $id, $term = null ) {
	if ( is_null( $term ) ) {
		$term = get_term( $id );
	}

	$data = array();
	foreach ( get_term_meta( $term->term_id ) as $key => $meta ) {
		$data[ $key ] = $meta[0];
	}

	return $data;
}

function boekdb_serie_data( $id, $term = null ) {
	if ( is_null( $term ) ) {
		$term = get_term( $id );
	}

	$meta  = get_term_meta( $term->term_id );
	$beeld = isset( $meta['boekdb_seriebeeld_id'] ) ? $meta['boekdb_seriebeeld_id'][0] : null;

	$data                       = array();
	$data['serie_omschrijving'] = $term->description;
	$data['serie_beeld_id']     = $beeld;

	return $data;
}

function boekdb_startswith( $haystack, $needle ) {
	return 0 === strpos( $haystack, $needle );
}

function boekdb_verschijningsvorm_slug( $code ) {
	if ( isset ( BoekDB_Translations::$verschijningsvorm[ $code ])) {
		return sanitize_title(BoekDB_Translations::$verschijningsvorm[ $code]);
	}

	return sanitize_title($code);
}

function boekdb_thema_omschrijving( $code ) {
	$code = strtoupper( $code );
	if ( isset( BoekDB_Translations::$thema[ $code ] ) ) {
		return BoekDB_Translations::$thema[ $code ];
	}

	return $code;
}

function boekdb_etalage_join( $join, $query) {
	global $wpdb;
	if ( ! is_admin() && ! $query->is_single() && $query->get('post_type') === 'boekdb_boek' && $query->get('etalage', false) && strlen($query->get('etalage', false)) > 0) {
		$table1 = $wpdb->prefix . 'boekdb_etalage_boeken';
		$table2 = $wpdb->prefix . 'boekdb_etalages';
		$join .= $wpdb->prepare(" LEFT JOIN {$table2} boekdb_e ON boekdb_e.name = %s", $query->get('etalage'));
		$join .= " INNER JOIN {$table1} boekdb_eb ON boekdb_eb.boek_id = {$wpdb->posts}.ID AND boekdb_eb.etalage_id = boekdb_e.id";
	}
	return $join;
}
add_filter('posts_join', 'boekdb_etalage_join', 10, 2);

function boekdb_add_minutely( $schedules ) {
	// add a 'minutely' schedule to the existing set
	$schedules['minutely'] = array(
		'interval' => 60,
		'display' => __('Every minute')
	);
	return $schedules;
}
add_filter( 'cron_schedules', 'boekdb_add_minutely' );
